# SmartExam Pro - Examination Portal Package

## 🔐 Admin Credentials
- **Username:** `sagar`
- **Password:** `SAGAR!`

## 📱 Device Compatibility
Designed and optimized for:
- Smart Phones (iOS Safari, Android Chrome)
- Tablets & iPads
- Laptops
- Desktops & Workstations

## 📚 Subject Coverage
1. **Java Programming** (OOP, Memory, Collections, Concurrency)
2. **Data Structures & Algorithms** (Trees, Stacks, Queues, Linked Lists, Graphs)
3. **Python Basics** (Data types, Comprehensions, Slicing, Functions)
4. **General Knowledge & Tech** (Computer Architecture, Computing Pioneers, Tech Milestones)

## 🎥 Recommended Learning Video Resources
- **Jenny's lectures CS IT**: https://www.youtube.com/@JennyslecturesCSIT
- **Shradha Khapra**: https://www.youtube.com/@shradhaKD
- **Apna College**: https://www.youtube.com/@ApnaCollegeOfficial

## 🚀 How to Run
1. Simply double-click `index.html` to open in any web browser!
2. No internet server required to run.
3. Questions and student results persist automatically in the browser storage.
